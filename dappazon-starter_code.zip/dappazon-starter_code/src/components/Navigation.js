import { ethers } from 'ethers';

const Navigation = ({ account, setAccount }) => {

    return (
        <nav>

        </nav>
    );
}

export default Navigation;